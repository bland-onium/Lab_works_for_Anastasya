﻿/*                  Вариант 8
 * Разработать класс по анализу HTML-содержимого web-страниц заданного интернет ресурса
 * Цель поиска – контактная информация (адрес, телефон)*/

using Lab_4_Nastya;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Ast
{
    internal class main
    {
        static void Main()
        {
            Menu.menu();
        }
    }
}
